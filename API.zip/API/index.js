var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var cors = require("cors");

var mysql = require("mysql");

app.use(bodyParser.json());
app.use(cors());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

// connection configurations
var dbConn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "hotel",
});
// connect to database
dbConn.connect();


app.get("/", function (req, res) {
  return res.send({ error: true, message: "hello" });
});

// Retrieve all hotels
app.get("/information", function (req, res) {
  dbConn.query("SELECT * FROM hotels", function (error, results, fields) {
    if (error) throw error;
    return res.send({ error: false, data: results, message: "Complete Data." });
  });
});
// Retrieve hotels with id
app.get("/mydata/:id", function (req, res) {
  let id = req.params.id;

  if (!id) {
    return res.status(400).send({ error: true, message: "Please provide id" });
  }

  dbConn.query("SELECT * FROM hotels where id=?", id, function (
    error,
    results,
    fields
  ) {
    if (error) throw error;
    return res.send({
      error: false,
      data: results[0],
      message: "Information by ID.",
    });
  });
});

// Add a new Record
app.post("/adduser", function (req, res) {
  let name = req.body.name;
  let fname = req.body.address;
  console.log(name + " " + address);
  if (!name && !address) {
    return res
      .status(400)
      .send({ error: true, message: "Please provide Information to be add" });
  }

  dbConn.query(
    "INSERT INTO hotels(name, address) value(?,?) ",
    [name, fname],
    function (error, results, fields) {
      if (error) throw error;
      return res.send({
        error: false,
        data: results,
        message: "Record has been added",
      });
    }
  );
});

//  Update hotel with id
app.put("/update", function (req, res) {
  let id = req.body.id;
  let name = req.body.name;
  let fname = req.body.address;
  if (!id || !name || !address) {
    return res.status(400).send({
      error: user,
      message: "Please provide full information with id",
    });
  }

  dbConn.query(
    "UPDATE hotels SET name = ?, address= ? WHERE id = ?",
    [name, fname, id],
    function (error, results, fields) {
      if (error) throw error;
      return res.send({ error: false, data: results, message: "data updated" });
    }
  );
});

//  Delete hotel
app.delete("/deleteuser", function (req, res) {
  let id = req.body.id;

  if (!id) {
    return res.status(400).send({ error: true, message: "Please provide id" });
  }
  dbConn.query("DELETE FROM hotels WHERE id = ?", [id], function (
    error,
    results,
    fields
  ) {
    if (error) throw error;
    return res.send({
      error: false,
      data: results,
      message: "Hotel Data has been deleted",
    });
  });
});
// set port
app.listen(3000, function () {
  console.log("Node app is running on port 3000");
});
module.exports = app;
